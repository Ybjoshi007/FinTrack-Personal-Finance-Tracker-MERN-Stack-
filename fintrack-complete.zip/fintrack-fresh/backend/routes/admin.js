const express = require('express');
const router = express.Router();
const protect = require('../middleware/authMiddleware');
const adminOnly = require('../middleware/adminMiddleware');
const { getAllUsers, getStats, deleteUser, toggleAdmin } = require('../controllers/adminController');

router.use(protect, adminOnly); // All routes require login + admin

router.get('/stats', getStats);
router.get('/users', getAllUsers);
router.delete('/users/:id', deleteUser);
router.patch('/users/:id/toggle-admin', toggleAdmin);

module.exports = router;
