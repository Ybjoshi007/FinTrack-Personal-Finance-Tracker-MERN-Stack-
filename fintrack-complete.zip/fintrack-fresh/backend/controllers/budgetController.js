const Budget = require('../models/Budget');
const Transaction = require('../models/Transaction');

// GET /api/budgets
const getBudgets = async (req, res) => {
  try {
    const month = req.query.month || new Date().toISOString().slice(0, 7);
    const budgets = await Budget.find({ user: req.user.id, month });

    // Calculate spending per category for this month
    const startDate = new Date(month + '-01');
    const endDate = new Date(startDate);
    endDate.setMonth(endDate.getMonth() + 1);

    const transactions = await Transaction.find({
      user: req.user.id,
      type: 'expense',
      date: { $gte: startDate, $lt: endDate },
    });

    const spending = {};
    transactions.forEach((t) => {
      spending[t.category] = (spending[t.category] || 0) + t.amount;
    });

    const result = budgets.map((b) => ({
      ...b.toObject(),
      spent: spending[b.category] || 0,
      remaining: b.limit - (spending[b.category] || 0),
      percentage: Math.round(((spending[b.category] || 0) / b.limit) * 100),
    }));

    res.json(result);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// POST /api/budgets
const setBudget = async (req, res) => {
  const { category, limit, month } = req.body;
  try {
    const budget = await Budget.findOneAndUpdate(
      { user: req.user.id, category, month },
      { limit },
      { upsert: true, new: true }
    );
    res.json(budget);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// DELETE /api/budgets/:id
const deleteBudget = async (req, res) => {
  try {
    await Budget.findOneAndDelete({ _id: req.params.id, user: req.user.id });
    res.json({ message: 'Budget deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

module.exports = { getBudgets, setBudget, deleteBudget };
