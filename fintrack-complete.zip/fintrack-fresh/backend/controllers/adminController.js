const User = require('../models/User');
const Transaction = require('../models/Transaction');

// GET /api/admin/users
const getAllUsers = async (req, res) => {
  try {
    const users = await User.find({}).select('-password').sort({ createdAt: -1 });

    // Get transaction count and total per user
    const enriched = await Promise.all(
      users.map(async (user) => {
        const txns = await Transaction.find({ user: user._id });
        const totalIncome = txns.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
        const totalExpense = txns.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
        return {
          ...user.toObject(),
          transactionCount: txns.length,
          totalIncome,
          totalExpense,
          balance: totalIncome - totalExpense,
        };
      })
    );

    res.json(enriched);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// GET /api/admin/stats
const getStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments({ isAdmin: false });
    const totalTransactions = await Transaction.countDocuments();
    const allTransactions = await Transaction.find({});
    const totalIncome = allTransactions.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
    const totalExpense = allTransactions.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);

    // New users this month
    const startOfMonth = new Date();
    startOfMonth.setDate(1); startOfMonth.setHours(0, 0, 0, 0);
    const newUsersThisMonth = await User.countDocuments({ createdAt: { $gte: startOfMonth } });

    res.json({ totalUsers, totalTransactions, totalIncome, totalExpense, newUsersThisMonth });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// DELETE /api/admin/users/:id
const deleteUser = async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    await Transaction.deleteMany({ user: req.params.id });
    res.json({ message: 'User and their transactions deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// PATCH /api/admin/users/:id/toggle-admin
const toggleAdmin = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    user.isAdmin = !user.isAdmin;
    await user.save();
    res.json({ message: `User is now ${user.isAdmin ? 'admin' : 'regular user'}`, isAdmin: user.isAdmin });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

module.exports = { getAllUsers, getStats, deleteUser, toggleAdmin };
