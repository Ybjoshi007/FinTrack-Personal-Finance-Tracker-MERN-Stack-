import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('fintrack_user');
    const savedToken = localStorage.getItem('fintrack_token');
    if (savedUser && savedToken) setUser(JSON.parse(savedUser));
    setLoading(false);
  }, []);

  const login = (userData, token) => {
    localStorage.setItem('fintrack_user', JSON.stringify(userData));
    localStorage.setItem('fintrack_token', token);
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('fintrack_user');
    localStorage.removeItem('fintrack_token');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
