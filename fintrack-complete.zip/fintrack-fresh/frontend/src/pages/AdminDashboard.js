import React, { useEffect, useState } from 'react';
import { getAdminStats, getAdminUsers, deleteAdminUser, toggleAdminRole } from '../api';

const fmt = (n) => '₹' + Number(n).toLocaleString('en-IN');

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
      const [statsRes, usersRes] = await Promise.all([getAdminStats(), getAdminUsers()]);
      setStats(statsRes.data);
      setUsers(usersRes.data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const handleDelete = async (id, name) => {
    if (!window.confirm('Delete user "' + name + '" and ALL their transactions?')) return;
    try {
      await deleteAdminUser(id);
      setUsers((prev) => prev.filter((u) => u._id !== id));
    } catch (err) { alert('Failed to delete user'); }
  };

  const handleToggleAdmin = async (id) => {
    try {
      const res = await toggleAdminRole(id);
      setUsers((prev) => prev.map((u) => u._id === id ? { ...u, isAdmin: res.data.isAdmin } : u));
    } catch (err) { alert('Failed to update role'); }
  };

  const filtered = users.filter((u) =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return <div className="loading">Loading admin panel...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1>Admin Dashboard</h1>
        <p>Manage all users and view platform statistics</p>
      </div>

      <div className="summary-grid" style={{ gridTemplateColumns: 'repeat(5, 1fr)', marginBottom: '2rem' }}>
        <div className="summary-card"><div className="label">Total Users</div><div className="amount" style={{ fontSize: '1.6rem' }}>{stats?.totalUsers || 0}</div></div>
        <div className="summary-card"><div className="label">New This Month</div><div className="amount" style={{ fontSize: '1.6rem', color: 'var(--blue)' }}>{stats?.newUsersThisMonth || 0}</div></div>
        <div className="summary-card"><div className="label">Transactions</div><div className="amount" style={{ fontSize: '1.6rem' }}>{stats?.totalTransactions || 0}</div></div>
        <div className="summary-card income"><div className="label">Platform Income</div><div className="amount">{fmt(stats?.totalIncome || 0)}</div></div>
        <div className="summary-card expense"><div className="label">Platform Expense</div><div className="amount">{fmt(stats?.totalExpense || 0)}</div></div>
      </div>

      <div className="admin-card">
        <div className="admin-card-header">
          <h2>All Users ({users.length})</h2>
          <div className="search-box" style={{ maxWidth: 300 }}>
            <span className="search-icon">🔍</span>
            <input type="text" placeholder="Search users..." value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
        </div>
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Name</th><th>Email</th><th>Role</th><th>Txns</th>
                <th>Income</th><th>Expenses</th><th>Balance</th><th>Joined</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u._id}>
                  <td><strong>{u.name}</strong></td>
                  <td style={{ color: 'var(--muted)', fontSize: '0.85rem' }}>{u.email}</td>
                  <td><span className={'role-badge ' + (u.isAdmin ? 'admin' : 'user')}>{u.isAdmin ? 'Admin' : 'User'}</span></td>
                  <td style={{ textAlign: 'center' }}>{u.transactionCount}</td>
                  <td style={{ color: 'var(--green)', fontFamily: 'monospace', fontSize: '0.85rem' }}>{fmt(u.totalIncome)}</td>
                  <td style={{ color: 'var(--red)', fontFamily: 'monospace', fontSize: '0.85rem' }}>{fmt(u.totalExpense)}</td>
                  <td style={{ color: u.balance >= 0 ? 'var(--green)' : 'var(--red)', fontFamily: 'monospace', fontSize: '0.85rem' }}>{fmt(u.balance)}</td>
                  <td style={{ color: 'var(--muted)', fontSize: '0.82rem' }}>{new Date(u.createdAt).toLocaleDateString('en-IN')}</td>
                  <td>
                    <div className="transaction-actions">
                      <button className="btn btn-success" onClick={() => handleToggleAdmin(u._id)}>{u.isAdmin ? 'Revoke' : 'Make Admin'}</button>
                      <button className="btn btn-danger" onClick={() => handleDelete(u._id, u.name)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && <tr><td colSpan="9" style={{ textAlign: 'center', padding: '2rem', color: 'var(--muted)' }}>No users found</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
