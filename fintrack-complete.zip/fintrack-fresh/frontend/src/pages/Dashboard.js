import React, { useEffect, useState } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from 'recharts';
import { getSummary, getTransactions, deleteTransaction } from '../api';
import { CATEGORY_ICONS } from '../components/AddTransaction';
import AddTransaction from '../components/AddTransaction';

const COLORS = ['#3b82f6','#22c55e','#f59e0b','#f43f5e','#a855f7','#06b6d4','#ec4899','#84cc16'];

const fmt = (n) => '₹' + Number(n).toLocaleString('en-IN');

const Dashboard = () => {
  const [summary, setSummary] = useState(null);
  const [recent, setRecent] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const [sumRes, txRes] = await Promise.all([getSummary(), getTransactions()]);
      setSummary(sumRes.data);
      setRecent(txRes.data.slice(0, 8));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const handleAdd = (newTx) => {
    setRecent((prev) => [newTx, ...prev].slice(0, 8));
    fetchData(); // refresh summary
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this transaction?')) return;
    try {
      await deleteTransaction(id);
      fetchData();
    } catch (err) {
      alert('Failed to delete');
    }
  };

  if (loading) return <div className="loading">Loading dashboard...</div>;

  // Prepare chart data
  const monthlyChartData = summary?.monthlyData
    ? Object.entries(summary.monthlyData).slice(-6).map(([month, val]) => ({
        month, Income: val.income, Expense: val.expense,
      }))
    : [];

  const pieData = summary?.categoryBreakdown
    ? Object.entries(summary.categoryBreakdown).map(([name, value]) => ({ name, value }))
    : [];

  return (
    <div className="page">
      <div className="page-header">
        <h1>Dashboard</h1>
        <p>Your financial overview at a glance</p>
      </div>

      {/* Summary Cards */}
      <div className="summary-grid">
        <div className="summary-card income">
          <div className="label">Total Income</div>
          <div className="amount">{fmt(summary?.totalIncome || 0)}</div>
        </div>
        <div className="summary-card expense">
          <div className="label">Total Expenses</div>
          <div className="amount">{fmt(summary?.totalExpense || 0)}</div>
        </div>
        <div className="summary-card balance">
          <div className="label">Net Balance</div>
          <div className="amount" style={{ color: (summary?.balance || 0) >= 0 ? 'var(--green)' : 'var(--red)' }}>
            {fmt(summary?.balance || 0)}
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="charts-grid">
        <div className="chart-card">
          <h3>Monthly Overview</h3>
          {monthlyChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={monthlyChartData} barSize={16}>
                <XAxis dataKey="month" tick={{ fill: '#8b90a7', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#8b90a7', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => '₹' + (v/1000).toFixed(0) + 'k'} />
                <Tooltip
                  contentStyle={{ background: '#1e2333', border: '1px solid #2a2f45', borderRadius: 8, fontSize: 13 }}
                  formatter={(v) => fmt(v)}
                />
                <Bar dataKey="Income" fill="#22c55e" radius={[4,4,0,0]} />
                <Bar dataKey="Expense" fill="#f43f5e" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="empty-state"><div className="icon">📊</div><p>No data yet</p></div>
          )}
        </div>

        <div className="chart-card">
          <h3>Expense Breakdown</h3>
          {pieData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="45%" innerRadius={55} outerRadius={80} paddingAngle={3} dataKey="value">
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip
                  contentStyle={{ background: '#1e2333', border: '1px solid #2a2f45', borderRadius: 8, fontSize: 12 }}
                  formatter={(v) => fmt(v)}
                />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11, color: '#8b90a7' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="empty-state"><div className="icon">🥧</div><p>No expenses yet</p></div>
          )}
        </div>
      </div>

      {/* Add Transaction */}
      <AddTransaction onAdd={handleAdd} />

      {/* Recent Transactions */}
      <div className="transaction-list">
        <div className="transaction-list-header">
          <h3>Recent Transactions</h3>
        </div>
        {recent.length === 0 ? (
          <div className="empty-state">
            <div className="icon">💳</div>
            <p>No transactions yet. Add one above!</p>
          </div>
        ) : (
          recent.map((tx) => (
            <div className="transaction-item" key={tx._id}>
              <div className={`transaction-icon ${tx.type}`}>
                {CATEGORY_ICONS[tx.category] || '💸'}
              </div>
              <div className="transaction-info">
                <div className="title">{tx.title}</div>
                <div className="meta">{tx.category} · {new Date(tx.date).toLocaleDateString('en-IN')}</div>
              </div>
              <div className={`transaction-amount ${tx.type}`}>
                {tx.type === 'income' ? '+' : '-'}{fmt(tx.amount)}
              </div>
              <div className="transaction-actions">
                <button className="btn btn-danger" onClick={() => handleDelete(tx._id)}>Delete</button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Dashboard;
