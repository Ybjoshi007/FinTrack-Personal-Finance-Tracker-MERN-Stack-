import React, { useEffect, useState, useCallback } from 'react';
import { getTransactions, deleteTransaction, updateTransaction } from '../api';
import AddTransaction, { CATEGORY_ICONS } from '../components/AddTransaction';

const fmt = (n) => '₹' + Number(n).toLocaleString('en-IN');

const INCOME_CATEGORIES = ['Salary', 'Freelance', 'Investment', 'Gift', 'Other Income'];
const EXPENSE_CATEGORIES = ['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment', 'Health', 'Education', 'Other Expense'];

const Transactions = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [filters, setFilters] = useState({
    search: '', type: 'all', category: 'all',
    startDate: '', endDate: '', sort: 'newest', recurring: false,
  });

  const fetchTransactions = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (filters.search) params.search = filters.search;
      if (filters.type !== 'all') params.type = filters.type;
      if (filters.category !== 'all') params.category = filters.category;
      if (filters.startDate) params.startDate = filters.startDate;
      if (filters.endDate) params.endDate = filters.endDate;
      if (filters.recurring) params.recurring = true;
      const res = await getTransactions(params);
      let data = res.data;
      if (filters.sort === 'oldest') data = [...data].sort((a, b) => new Date(a.date) - new Date(b.date));
      else if (filters.sort === 'highest') data = [...data].sort((a, b) => b.amount - a.amount);
      else if (filters.sort === 'lowest') data = [...data].sort((a, b) => a.amount - b.amount);
      setTransactions(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    const timer = setTimeout(fetchTransactions, 300);
    return () => clearTimeout(timer);
  }, [fetchTransactions]);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this transaction?')) return;
    try {
      await deleteTransaction(id);
      setTransactions((prev) => prev.filter((t) => t._id !== id));
    } catch (err) { alert('Failed to delete'); }
  };

  const startEdit = (tx) => {
    setEditingId(tx._id);
    setEditForm({
      title: tx.title, amount: tx.amount,
      category: tx.category, type: tx.type,
      date: new Date(tx.date).toISOString().split('T')[0],
      note: tx.note || '',
      isRecurring: tx.isRecurring || false,
      recurringFrequency: tx.recurringFrequency || 'monthly',
    });
  };

  const saveEdit = async (id) => {
    try {
      const res = await updateTransaction(id, { ...editForm, amount: Number(editForm.amount) });
      setTransactions((prev) => prev.map((t) => (t._id === id ? res.data : t)));
      setEditingId(null);
    } catch (err) { alert('Failed to update'); }
  };

  const categories = editForm.type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  return (
    <div className="page">
      <div className="page-header">
        <h1>All Transactions</h1>
        <p>{transactions.length} transactions found</p>
      </div>

      <AddTransaction onAdd={(tx) => setTransactions((prev) => [tx, ...prev])} />

      {/* Search & Filters */}
      <div className="filter-bar">
        <div className="search-box">
          <span className="search-icon">🔍</span>
          <input
            type="text" placeholder="Search by title..."
            value={filters.search}
            onChange={(e) => setFilters({ ...filters, search: e.target.value })}
          />
        </div>
        <div className="filters">
          <select value={filters.type} onChange={(e) => setFilters({ ...filters, type: e.target.value, category: 'all' })}>
            <option value="all">All Types</option>
            <option value="income">Income</option>
            <option value="expense">Expense</option>
          </select>
          <select value={filters.category} onChange={(e) => setFilters({ ...filters, category: e.target.value })}>
            <option value="all">All Categories</option>
            {(filters.type === 'income' ? INCOME_CATEGORIES : filters.type === 'expense' ? EXPENSE_CATEGORIES : [...INCOME_CATEGORIES, ...EXPENSE_CATEGORIES]).map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <select value={filters.sort} onChange={(e) => setFilters({ ...filters, sort: e.target.value })}>
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="highest">Highest Amount</option>
            <option value="lowest">Lowest Amount</option>
          </select>
        </div>
        <div className="date-filters">
          <label>From</label>
          <input type="date" value={filters.startDate} onChange={(e) => setFilters({ ...filters, startDate: e.target.value })} />
          <label>To</label>
          <input type="date" value={filters.endDate} onChange={(e) => setFilters({ ...filters, endDate: e.target.value })} />
          {(filters.startDate || filters.endDate) && (
            <button className="clear-btn" onClick={() => setFilters({ ...filters, startDate: '', endDate: '' })}>✕ Clear</button>
          )}
        </div>
        <label className="checkbox-label">
          <input type="checkbox" checked={filters.recurring} onChange={(e) => setFilters({ ...filters, recurring: e.target.checked })} />
          <span>Recurring only</span>
        </label>
      </div>

      {/* Transaction List */}
      <div className="transaction-list">
        <div className="transaction-list-header">
          <h3>Transactions ({transactions.length})</h3>
        </div>

        {loading ? (
          <div className="empty-state"><p>Loading...</p></div>
        ) : transactions.length === 0 ? (
          <div className="empty-state">
            <div className="icon">🔍</div>
            <p>No transactions match your filters</p>
          </div>
        ) : (
          transactions.map((tx) => (
            <div className="transaction-item" key={tx._id}>
              {editingId === tx._id ? (
                <div className="edit-form-inline">
                  <div className="edit-grid">
                    <div className="form-group">
                      <label>Title</label>
                      <input value={editForm.title} onChange={(e) => setEditForm({ ...editForm, title: e.target.value })} />
                    </div>
                    <div className="form-group">
                      <label>Amount (₹)</label>
                      <input type="number" value={editForm.amount} onChange={(e) => setEditForm({ ...editForm, amount: e.target.value })} />
                    </div>
                    <div className="form-group">
                      <label>Category</label>
                      <select value={editForm.category} onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}>
                        {categories.map((c) => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div className="form-group">
                      <label>Date</label>
                      <input type="date" value={editForm.date} onChange={(e) => setEditForm({ ...editForm, date: e.target.value })} />
                    </div>
                    <div className="form-group" style={{ gridColumn: 'span 2' }}>
                      <label>Note</label>
                      <input value={editForm.note} onChange={(e) => setEditForm({ ...editForm, note: e.target.value })} placeholder="Note..." />
                    </div>
                  </div>
                  <div className="edit-actions">
                    <button className="btn btn-success" onClick={() => saveEdit(tx._id)}>Save</button>
                    <button className="btn btn-danger" onClick={() => setEditingId(null)}>Cancel</button>
                  </div>
                </div>
              ) : (
                <>
                  <div className={`transaction-icon ${tx.type}`}>{CATEGORY_ICONS[tx.category] || '💸'}</div>
                  <div className="transaction-info">
                    <div className="title">
                      {tx.title}
                      {tx.isRecurring && <span className="recurring-badge">🔁 {tx.recurringFrequency}</span>}
                    </div>
                    <div className="meta">{tx.category} · {new Date(tx.date).toLocaleDateString('en-IN')}{tx.note && ` · ${tx.note}`}</div>
                  </div>
                  <div className={`transaction-amount ${tx.type}`}>
                    {tx.type === 'income' ? '+' : '-'}{fmt(tx.amount)}
                  </div>
                  <div className="transaction-actions">
                    <button className="btn btn-success" onClick={() => startEdit(tx)}>Edit</button>
                    <button className="btn btn-danger" onClick={() => handleDelete(tx._id)}>Delete</button>
                  </div>
                </>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Transactions;
