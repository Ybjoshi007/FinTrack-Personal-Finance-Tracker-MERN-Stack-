import React, { useEffect, useState } from 'react';
import { getBudgets, setBudget, deleteBudget } from '../api';

const EXPENSE_CATEGORIES = ['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment', 'Health', 'Education', 'Other Expense'];
const CATEGORY_ICONS = { Food:'🍔', Transport:'🚗', Shopping:'🛍️', Bills:'🧾', Entertainment:'🎬', Health:'💊', Education:'📚', 'Other Expense':'💸' };
const fmt = (n) => '₹' + Number(n).toLocaleString('en-IN');

const Budgets = () => {
  const [budgets, setBudgetsState] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ category: 'Food', limit: '' });
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const fetchBudgets = async () => {
    setLoading(true);
    try {
      const res = await getBudgets(month);
      setBudgetsState(res.data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchBudgets(); }, [month]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.limit || Number(form.limit) <= 0) return setError('Enter a valid limit');
    setError(''); setSaving(true);
    try {
      await setBudget({ ...form, limit: Number(form.limit), month });
      setForm({ category: 'Food', limit: '' });
      fetchBudgets();
    } catch (err) { setError(err.response?.data?.message || 'Failed to save budget'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    try {
      await deleteBudget(id);
      setBudgetsState((prev) => prev.filter((b) => b._id !== id));
    } catch (err) { alert('Failed to delete budget'); }
  };

  const getBarColor = (pct) => pct >= 100 ? 'var(--red)' : pct >= 75 ? 'var(--yellow)' : 'var(--green)';

  return (
    <div className="page">
      <div className="page-header">
        <h1>Budget Limits</h1>
        <p>Set monthly spending limits per category</p>
      </div>

      <div className="budget-controls">
        <label>Viewing month:</label>
        <input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="month-input" />
      </div>

      <div className="add-form-card">
        <div className="add-form-header"><h2>Set Budget</h2></div>
        <div className="add-form-body">
          {error && <div className="error-msg">{error}</div>}
          <form onSubmit={handleSubmit}>
            <div className="form-grid">
              <div className="form-group">
                <label>Category</label>
                <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                  {EXPENSE_CATEGORIES.map((c) => <option key={c} value={c}>{CATEGORY_ICONS[c]} {c}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Monthly Limit (₹)</label>
                <input type="number" min="1" placeholder="e.g. 5000" value={form.limit} onChange={(e) => setForm({ ...form, limit: e.target.value })} />
              </div>
            </div>
            <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Set Budget'}</button>
          </form>
        </div>
      </div>

      {loading ? <div className="loading">Loading budgets...</div>
        : budgets.length === 0 ? (
          <div className="empty-state"><div className="icon">🎯</div><p>No budgets set for this month. Add one above!</p></div>
        ) : (
          <div className="budget-grid">
            {budgets.map((b) => (
              <div className={`budget-card ${b.percentage >= 100 ? 'over-budget' : ''}`} key={b._id}>
                <div className="budget-card-header">
                  <span className="budget-icon">{CATEGORY_ICONS[b.category]}</span>
                  <span className="budget-category">{b.category}</span>
                  <button className="btn btn-danger" onClick={() => handleDelete(b._id)}>✕</button>
                </div>
                <div className="budget-amounts">
                  <span className="spent">{fmt(b.spent)} spent</span>
                  <span className="limit">of {fmt(b.limit)}</span>
                </div>
                <div className="budget-bar-bg">
                  <div className="budget-bar-fill" style={{ width: `${Math.min(b.percentage, 100)}%`, background: getBarColor(b.percentage) }} />
                </div>
                <div className="budget-footer">
                  <span style={{ color: getBarColor(b.percentage) }}>
                    {b.percentage >= 100 ? `Over budget by ${fmt(Math.abs(b.remaining))}` : b.percentage >= 75 ? `${b.percentage}% used — almost there` : `${b.percentage}% used`}
                  </span>
                  <span className="remaining">{b.remaining >= 0 ? `${fmt(b.remaining)} left` : ''}</span>
                </div>
              </div>
            ))}
          </div>
        )}
    </div>
  );
};

export default Budgets;
