import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <NavLink to="/" className="navbar-brand">FINTRACK</NavLink>
      <div className="navbar-nav">
        <NavLink to="/" end className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}>Dashboard</NavLink>
        <NavLink to="/transactions" className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}>Transactions</NavLink>
        <NavLink to="/budgets" className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}>Budgets</NavLink>
        {user?.isAdmin && (
          <NavLink to="/admin" className={({ isActive }) => 'nav-link admin-link' + (isActive ? ' active' : '')}>
            Admin
          </NavLink>
        )}
        <span className="nav-user">Hi, {user?.name}</span>
        <button className="btn-logout" onClick={handleLogout}>Logout</button>
      </div>
    </nav>
  );
};

export default Navbar;
