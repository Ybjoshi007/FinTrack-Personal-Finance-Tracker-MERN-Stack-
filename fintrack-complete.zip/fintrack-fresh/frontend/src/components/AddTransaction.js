import React, { useState } from 'react';
import { createTransaction } from '../api';

const INCOME_CATEGORIES = ['Salary', 'Freelance', 'Investment', 'Gift', 'Other Income'];
const EXPENSE_CATEGORIES = ['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment', 'Health', 'Education', 'Other Expense'];

export const CATEGORY_ICONS = {
  Salary: '💼', Freelance: '💻', Investment: '📈', Gift: '🎁', 'Other Income': '💰',
  Food: '🍔', Transport: '🚗', Shopping: '🛍️', Bills: '🧾', Entertainment: '🎬',
  Health: '💊', Education: '📚', 'Other Expense': '💸',
};

const AddTransaction = ({ onAdd }) => {
  const [form, setForm] = useState({
    title: '', amount: '', type: 'expense', category: 'Food',
    date: new Date().toISOString().split('T')[0], note: '',
    isRecurring: false, recurringFrequency: 'monthly',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);

  const handleTypeChange = (type) => {
    setForm({ ...form, type, category: type === 'income' ? 'Salary' : 'Food' });
  };

  const handleChange = (e) => {
    const val = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setForm({ ...form, [e.target.name]: val });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.amount) return setError('Title and amount are required');
    if (isNaN(form.amount) || Number(form.amount) <= 0) return setError('Enter a valid amount');
    setError(''); setLoading(true);
    try {
      const res = await createTransaction({ ...form, amount: Number(form.amount) });
      onAdd(res.data);
      setForm({ title: '', amount: '', type: 'expense', category: 'Food', date: new Date().toISOString().split('T')[0], note: '', isRecurring: false, recurringFrequency: 'monthly' });
      setOpen(false);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to add transaction');
    } finally {
      setLoading(false);
    }
  };

  const categories = form.type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  return (
    <div className="add-form-card">
      <div className="add-form-header" onClick={() => setOpen(!open)}>
        <h2>+ Add Transaction</h2>
        <span className="toggle-icon">{open ? '▲' : '▼'}</span>
      </div>

      {open && (
        <div className="add-form-body">
          {error && <div className="error-msg">{error}</div>}
          <form onSubmit={handleSubmit}>
            <div className="form-grid">
              <div className="form-group full">
                <label>Type</label>
                <div className="type-toggle">
                  <button type="button" className={`type-btn income ${form.type === 'income' ? 'active' : ''}`} onClick={() => handleTypeChange('income')}>+ Income</button>
                  <button type="button" className={`type-btn expense ${form.type === 'expense' ? 'active' : ''}`} onClick={() => handleTypeChange('expense')}>- Expense</button>
                </div>
              </div>
              <div className="form-group">
                <label>Title</label>
                <input name="title" value={form.title} onChange={handleChange} placeholder="e.g. Monthly Salary" />
              </div>
              <div className="form-group">
                <label>Amount (₹)</label>
                <input name="amount" value={form.amount} onChange={handleChange} placeholder="e.g. 5000" type="number" min="1" />
              </div>
              <div className="form-group">
                <label>Category</label>
                <select name="category" value={form.category} onChange={handleChange}>
                  {categories.map((c) => <option key={c} value={c}>{CATEGORY_ICONS[c]} {c}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Date</label>
                <input name="date" type="date" value={form.date} onChange={handleChange} />
              </div>
              <div className="form-group full">
                <label>Note (optional)</label>
                <input name="note" value={form.note} onChange={handleChange} placeholder="Any additional note..." />
              </div>
              <div className="form-group full recurring-row">
                <label className="checkbox-label">
                  <input type="checkbox" name="isRecurring" checked={form.isRecurring} onChange={handleChange} />
                  <span>Recurring transaction</span>
                </label>
                {form.isRecurring && (
                  <select name="recurringFrequency" value={form.recurringFrequency} onChange={handleChange} style={{ marginLeft: '1rem', width: 'auto' }}>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="yearly">Yearly</option>
                  </select>
                )}
              </div>
            </div>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Adding...' : 'Add Transaction'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default AddTransaction;
