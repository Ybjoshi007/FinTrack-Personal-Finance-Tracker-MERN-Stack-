# 💰 FinTrack — Personal Finance Tracker
> Full-stack MERN web app | 6th Sem CSE Project

## Tech Stack
- **M** — MongoDB + Mongoose
- **E** — Express.js
- **R** — React.js + Recharts
- **N** — Node.js + JWT Auth

---

## 🚀 How to Run (Fresh Setup)

### Prerequisites
- Node.js installed ✅
- MongoDB installed ✅

---

### Step 1 — Start MongoDB
Open Terminal 1 and run:
```
mongod
```
Keep it open.

---

### Step 2 — Start Backend
Open Terminal 2 and run:
```
cd fintrack/backend
npm install
npm run dev
```
You should see:
```
✅ MongoDB connected
🚀 Server running on port 5000
```

---

### Step 3 — Start Frontend
Open Terminal 3 and run:
```
cd fintrack/frontend
npm install
npm start
```
Browser opens at: **http://localhost:3000**

---

## 👑 How to Make Yourself Admin

1. Register an account in the app
2. Open MongoDB Compass → connect to `mongodb://localhost:27017`
3. Go to `fintrack` → `users` → click your user
4. Change `isAdmin` from `false` to `true` → Save
5. Refresh the app → Admin link appears in navbar

---

## Features
- Register / Login with JWT auth
- Add Income & Expense transactions
- Dashboard with bar chart + pie chart
- Search transactions by title
- Filter by type, category, date range
- Edit & Delete transactions
- Recurring transactions (weekly/monthly/yearly)
- Budget limits per category with progress bar
- Admin dashboard — manage all users & view stats

---

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| POST | /api/auth/register | Register |
| POST | /api/auth/login | Login |
| GET | /api/transactions | Get all (supports search/filter) |
| POST | /api/transactions | Add transaction |
| PUT | /api/transactions/:id | Update |
| DELETE | /api/transactions/:id | Delete |
| GET | /api/transactions/summary | Dashboard summary |
| GET | /api/budgets | Get budgets |
| POST | /api/budgets | Set budget |
| DELETE | /api/budgets/:id | Delete budget |
| GET | /api/admin/stats | Admin stats |
| GET | /api/admin/users | All users |
| DELETE | /api/admin/users/:id | Delete user |
| PATCH | /api/admin/users/:id/toggle-admin | Toggle admin role |

---

Developed by: [Your Name] | CSE 6th Semester
